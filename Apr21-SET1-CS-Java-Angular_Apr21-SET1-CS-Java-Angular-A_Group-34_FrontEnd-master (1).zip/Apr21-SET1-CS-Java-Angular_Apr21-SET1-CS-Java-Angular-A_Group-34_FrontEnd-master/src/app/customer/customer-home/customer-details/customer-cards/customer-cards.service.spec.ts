import { TestBed } from '@angular/core/testing';

import { CustomerCardsService } from './customer-cards.service';

describe('CustomerCardsService', () => {
  let service: CustomerCardsService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(CustomerCardsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
