package com.infy.ekart.service.test;

import java.security.NoSuchAlgorithmException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;

import com.infy.ekart.dto.CardDTO;
import com.infy.ekart.entity.Card;
import com.infy.ekart.entity.Customer;
import com.infy.ekart.exception.EKartException;
import com.infy.ekart.repository.CustomerCardRepository;
import com.infy.ekart.repository.CustomerRepository;
import com.infy.ekart.service.CustomerCardService;
import com.infy.ekart.service.CustomerCardServiceImpl;
import com.infy.ekart.service.CustomerService;
import com.infy.ekart.service.CustomerServiceImpl;


@SpringBootTest
public class CustomerCardServiceTest {
	// Mocking customer repository 
	@Mock
	CustomerRepository customerRepository;
	
	//Mocking customer card repository
	@Mock
	CustomerCardRepository customerCardRepository;
	
	//Injecting the customer card service
	@InjectMocks
	CustomerCardService customerCardService = new CustomerCardServiceImpl();
	
	//Injecting the customer service 
	@InjectMocks
	CustomerService customerService = new CustomerServiceImpl();
	
	//Invalid test cases for adding customer card with invalid email ID
	@Test
	public void addCustomerCardsCustomerNotFound() throws EKartException{
		
		//Create parameters for the target function
		CardDTO cardDTO = new CardDTO();
		cardDTO.setCardType("CREDIT_CARD");
		cardDTO.setCardNumber("1234765487675645");
		cardDTO.setCvv("156");
		cardDTO.setExpiryDate(LocalDate.of(2022, 12, 1));
		cardDTO.setNameOnCard("Thomas");
		//Create parameters for the executing function
		String emailId = "thomas@infosys.com";
		
		//Mock the repository used in the target function
		Mockito.when(customerRepository.findById(Mockito.anyString())).thenReturn(Optional.empty());
		
		//Validating the output by calling target function
		Exception exception = Assertions.assertThrows(EKartException.class,
				()->customerCardService.addCustomerCards(cardDTO, emailId));
		Assertions.assertEquals("Service.CUSTOMER_NOT_FOUND", exception.getMessage());
		
	}
	
	//Invalid test case for adding customer card which is already existing in DB
	@Test
	public void addCustomerCardsAlreadyExist()throws EKartException{
		
		//Create parameters for the target function
				CardDTO cardDTO = new CardDTO();
				cardDTO.setCardType("CREDIT_CARD");
				cardDTO.setCardNumber("1234765487675645");
				cardDTO.setCvv("156");
				cardDTO.setExpiryDate(LocalDate.of(2022, 12, 1));
				cardDTO.setNameOnCard("Thomas");
		//Create parameters for the executing function
				String emailId = "thomas@infosys.com";
		
		//Intermediate response from repository function i.e, (customerRepository.findById())		
				Customer customer = new Customer();
				customer.setEmailId("thomas@infosys.com");
				
		//Intermediate response from repository function i.e, 
				//                       (customerCardRepository.findByCardNumber)
				Card card = new Card();
				card.setCardId(202035);
				card.setCardNumber(cardDTO.getCardNumber());
				
		//Mocking customerRepository function		
				Mockito.when(customerRepository.findById(Mockito.anyString()))
				.thenReturn(Optional.of(customer));
				
		//Mocking customerCardRepository function		
				Mockito.when(customerCardRepository.findByCardNumber(Mockito.anyString()))
				.thenReturn(card);
			
		   
		//Validating the output by calling target function				
		   Exception exception = Assertions.assertThrows(EKartException.class,
				   ()->customerCardService.addCustomerCards(cardDTO, emailId));	
		   
		   Assertions.assertEquals("Service.CARD_ALREADY_EXIST", exception.getMessage());
					
	}
	
	//Invalid test case for deleting a customer card which is not present in DB
	@Test
	public void deleteCustomerCardCardNotFound() {
		Integer cardId = 101080;
		Mockito.when(customerCardRepository.findById(Mockito.anyInt()))
		.thenReturn(Optional.empty());
		Exception exception = Assertions.assertThrows(EKartException.class,
				()->customerCardService.deleteCustomerCard(cardId));
		Assertions.assertEquals("Service.CARD_NOT_FOUND", exception.getMessage());
	}
	
	//Invalid test case for fetching the card for the customer who is not existing.
	@Test
	public void getCustomerCardsCustomerNotFound() {
		String emailId =  "thomas@infosys.com";
		
		Mockito.when(customerRepository.findById(Mockito.anyString()))
		.thenReturn(Optional.empty());
		
		Exception exception =Assertions.assertThrows(EKartException.class,
				()->customerCardService.getCustomerCards(emailId));
		Assertions.assertEquals("Service.CUSTOMER_NOT_FOUND", exception.getMessage());
	}
	
	//Invalid test case for fetching customer card which doesn't exist in the DB.
	@Test
	public void getCustomerCardsCardNotFound() {
		String emailId =  "thomas@infosys.com";
		
		Customer customer = new Customer();
		customer.setEmailId("thomas@infosys.com");
		customer.setCards(List.of());
	
		Mockito.when(customerRepository.findById(Mockito.anyString()))
		.thenReturn(Optional.of(customer));
		
		Exception exception = Assertions.assertThrows(EKartException.class,
								()->customerCardService.getCustomerCards(emailId));
		Assertions.assertEquals("Service.NO_CARDS_TO_SHOW", exception.getMessage());	
		
	}
	
	
	@Test
	public void getCustomerCardValid()throws EKartException {
		String emailId =  "thomas@infosys.com";
		
		Customer customer = new Customer();
		customer.setEmailId("thomas@infosys.com");
		List<Card> cards= new ArrayList<Card>();
		customer.setCards(cards);
		
		Card card = new Card();
		card.setCardId(123432);
		card.setCardNumber("6765676567654567");
		card.setCardType("DEBIT_CARD");
		card.setCvv("234");
		card.setExpiryDate(LocalDate.of(2022,11,12));
		card.setNameOnCard("Tom");
		cards.add(card);
		customer.setCards(cards);
		
		
		Mockito.when(customerRepository.findById(Mockito.anyString()))
		.thenReturn(Optional.of(customer));
		List<CardDTO> cardReturned = customerCardService.getCustomerCards(emailId);	
		Assertions.assertNotNull(cardReturned);
	}
	
	//Valid test case for adding customer card to DB.
	@Test
	public void addCustomerCardValid()throws EKartException,NoSuchAlgorithmException{
		
		CardDTO cardDTO = new CardDTO();
		//cardDTO.setCardId(202090);
		cardDTO.setCardNumber("7685768576857685");
		cardDTO.setCardType("DEBIT_CARD");
		cardDTO.setCvv("321");
		cardDTO.setExpiryDate(LocalDate.of(2022,12,28));
		cardDTO.setNameOnCard("Thomas");
		
		String emailId = "thomas@infosys.com";
		
		Customer customer = new Customer();
		customer.setEmailId(emailId);
		customer.setCards(new ArrayList<>());
		Optional<Customer> optionalCustomer = Optional.of(customer);
		
		Mockito.when(customerRepository.findById(Mockito.anyString()))
		.thenReturn(optionalCustomer);
		
		Mockito.when(customerCardRepository.findByCardNumber(Mockito.anyString()))
		.thenReturn(null);
		
		Mockito.when(customerRepository.save(Mockito.any())).thenReturn(customer);
		
		
		Assertions.assertDoesNotThrow(()->customerCardService
				.addCustomerCards(cardDTO, emailId));
			
	}
	
	//Valid test case for deleting the customer card from DB.
	@Test
	public void deleteCustomerCardValid()throws EKartException{
		
		Integer cardId = 101010; 
		Card card = new Card();
		card.setCardId(202020);
		card.setCardNumber("1232123432123432");
		card.setCardType("CREDIT_CARD");
		card.setCvv("123");
		card.setExpiryDate(LocalDate.of(2022,04,01));
		card.setNameOnCard("Thomas");
		
		
		
		Mockito.when(customerCardRepository.findById(Mockito.anyInt()))
		.thenReturn(Optional.of(card));
		
		Assertions.assertDoesNotThrow(()->customerCardService.deleteCustomerCard(cardId));
		
	}
	
	
}
