package com.infy.ekart.api;

import java.security.NoSuchAlgorithmException;
import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.infy.ekart.dto.CardDTO;
import com.infy.ekart.exception.EKartException;
import com.infy.ekart.service.CustomerCardService;



@CrossOrigin
@RestController
@RequestMapping(value = "/customercard-api")
@Validated
public class CustomerCardAPI {
	
	    //Injecting customerService
		@Autowired
	 	private CustomerCardService customerCardService;
		//Injecting environment
	    @Autowired
	    private Environment environment;
	    
	    
	    //API for fetching Customer Cards
	    @GetMapping(value = "/customers/{customerEmailId:.+}/customerCards")
	    public ResponseEntity<List<CardDTO>> getCustomerCards(
	    		@Pattern(regexp = "[a-zA-Z0-9._]+@[a-zA-Z]{2,}\\.[a-zA-Z][a-zA-Z.]+", message = "{invalid.email.format}")
	    		@PathVariable String customerEmailId) throws EKartException {
	    	
	    	
	    	List<CardDTO> cardList = null;
	         cardList = customerCardService.getCustomerCards(customerEmailId);
	        return new ResponseEntity<>(cardList, HttpStatus.OK);
	    }

	    //API for add customer cards
	    @PostMapping(value = "/customers/addCard/{customerEmailId:.+}/customerCards")
	    public ResponseEntity<String> addCustomerCards(@Valid @RequestBody CardDTO card,
	    		@Pattern(regexp = "[a-zA-Z0-9._]+@[a-zA-Z]{2,}\\.[a-zA-Z][a-zA-Z.]+", message = "{invalid.email.format}")
	    		@PathVariable("customerEmailId") String customerEmailId)
	    		throws EKartException,NoSuchAlgorithmException {
			 customerCardService.addCustomerCards(card, customerEmailId);
			String successMessage = environment.getProperty("CustomerCardAPI.CARD_INSERTION_SUCCESS");
			String toReturn = successMessage;
			toReturn = toReturn.trim();
			return new ResponseEntity<>(toReturn, HttpStatus.OK);
		}
	    
	    //API for deleting customer cards
	    @DeleteMapping(value="/customers/deleteCard/{cardId}/customerCards")
	    public ResponseEntity<String> deleteCustomerCard(@PathVariable Integer cardId)
	    	throws EKartException{
	    	
	    	customerCardService.deleteCustomerCard(cardId);
	    	String successMessage = environment.getProperty("CustomerCardAPI.CARD_DELETED_SUCCESS");
	    	return new ResponseEntity<String>(successMessage,HttpStatus.OK);	    
	    	
    	
	    }
	    
	

}
