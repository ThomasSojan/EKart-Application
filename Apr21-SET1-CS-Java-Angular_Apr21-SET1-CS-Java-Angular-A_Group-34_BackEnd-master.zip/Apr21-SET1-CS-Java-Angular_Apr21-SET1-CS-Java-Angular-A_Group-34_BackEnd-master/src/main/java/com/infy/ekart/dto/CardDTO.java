package com.infy.ekart.dto;

import java.time.LocalDate;

import javax.validation.constraints.Future;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;





public class CardDTO {
	
	
	
	private Integer cardId;
	
	@NotNull(message="{card.cardType.absent}")
	@Pattern(regexp="(DEBIT_CARD|CREDIT_CARD)")
	private String cardType;
	
	@NotNull(message="{card.cardNumber.absent}")
	@Pattern(regexp = "[0-9]{16}", message="{card.cardNumber.invalid}")
	private String cardNumber;
	
	@NotNull(message = "{card.cvv.absent}")
	@Pattern(regexp = "[0-9]{3}",message = "{card.cvv.invalid}")
	private String cvv;
	
	@Future(message = "{card.expiryDate.invalid}")
	private LocalDate expiryDate;
	
	@NotNull(message = "{card.Name.absent}")
	private String nameOnCard;

	
	
	


	public Integer getCardId() {
		return cardId;
	}


	public void setCardId(Integer cardId) {
		this.cardId = cardId;
	}


	public String getCardType() {
		return cardType;
	}


	public void setCardType(String cardType) {
		this.cardType = cardType;
	}


	public String getCardNumber() {
		return cardNumber;
	}


	public void setCardNumber(String cardNumber) {
		this.cardNumber = cardNumber;
	}


	public String getCvv() {
		return cvv;
	}


	public void setCvv(String cvv) {
		this.cvv = cvv;
	}


	public LocalDate getExpiryDate() {
		return expiryDate;
	}


	public void setExpiryDate(LocalDate expiryDate) {
		this.expiryDate = expiryDate;
	}


	public String getNameOnCard() {
		return nameOnCard;
	}


	public void setNameOnCard(String nameOnCard) {
		this.nameOnCard = nameOnCard;
	}




}
