package com.infy.ekart.service;

import java.security.NoSuchAlgorithmException;
import java.util.List;

import com.infy.ekart.dto.CardDTO;
import com.infy.ekart.exception.EKartException;

public interface CustomerCardService {
	 
	 //Function for fetching customer cards using email id
	 List<CardDTO> getCustomerCards( String customerEmailId) throws EKartException;
	 
	 //Function for adding customer cards using customer email id
	 void addCustomerCards(CardDTO cardDto,String customerEmailId) throws EKartException,NoSuchAlgorithmException;
	 
	 //Function for deleting customer cards using card id
	 void deleteCustomerCard(Integer cardId) throws EKartException;

}
