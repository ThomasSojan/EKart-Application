package com.infy.ekart.service;

import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;


import com.infy.ekart.dto.CardDTO;
import com.infy.ekart.entity.Card;
import com.infy.ekart.entity.Customer;
import com.infy.ekart.exception.EKartException;
import com.infy.ekart.repository.CustomerCardRepository;
import com.infy.ekart.repository.CustomerRepository;
import com.infy.ekart.utility.HashingUtility;





@Service(value = "customerCardService")
@Transactional
public class CustomerCardServiceImpl implements CustomerCardService{
	
	//Injecting customer repository
	@Autowired
	private CustomerRepository customerRepository;
	
	//Injecting customer card repository
	@Autowired
	private CustomerCardRepository customerCardRepository;
	
	//Function for returning list of cards by using customer email id
	@Override
	public List<CardDTO> getCustomerCards(String customerEmailId) throws EKartException {
		// TODO Auto-generated method stub
		
		Optional<Customer> optional = customerRepository.findById(customerEmailId.toLowerCase());
		Customer customer = optional.orElseThrow(()-> new EKartException("Service.CUSTOMER_NOT_FOUND"));
		List<Card> cards = customer.getCards();
		if(cards.isEmpty()) {
			throw new EKartException("Service.NO_CARDS_TO_SHOW");
			}

		//Populating cardDTO using card Entity.
		ArrayList<CardDTO> cardDTOList = new ArrayList<CardDTO>();
		cards.forEach(card-> {
			CardDTO cardDTO = new CardDTO();
			cardDTO.setCardId(card.getCardId());
			cardDTO.setCardNumber(card.getCardNumber());
			cardDTO.setCvv(card.getCvv());
			cardDTO.setExpiryDate(card.getExpiryDate());
			cardDTO.setNameOnCard(card.getNameOnCard());
			cardDTO.setCardType(card.getCardType());
			cardDTOList.add(cardDTO);
			
		});
		return cardDTOList;	
	}


    //Function for adding customer card using customer email id
	@Override
	public void addCustomerCards(CardDTO cardDto, String customerEmailId) throws EKartException,NoSuchAlgorithmException {
		// TODO Auto-generated method stub
		Optional<Customer> optional = customerRepository.findById(customerEmailId.toLowerCase());
		Customer customer = optional.orElseThrow(()-> new EKartException("Service.CUSTOMER_NOT_FOUND"));
		Card c = customerCardRepository.findByCardNumber(cardDto.getCardNumber());
		Card cardEntity = new Card();
		if(c != null)
			throw new EKartException("Service.CARD_ALREADY_EXIST");
		else {
			//Populating Card Entity using cardDTO.
			List<Card> cardList = customer.getCards();
			cardEntity.setCardNumber(cardDto.getCardNumber());
			cardEntity.setCardType(cardDto.getCardType());
			cardEntity.setCvv(HashingUtility.getHashValue(cardDto.getCvv()));
			cardEntity.setExpiryDate(cardDto.getExpiryDate());
			cardEntity.setNameOnCard(cardDto.getNameOnCard());
			cardList.add(cardEntity);
			customer.setCards(cardList);
			// Saving the customer Entity to DB.
			customerRepository.save(customer);
		    
		}	
		
	} 
	
	//Function for deleting customer card using card id
	@Override
	public void deleteCustomerCard(Integer cardId) throws EKartException {
		// TODO Auto-generated method stub
		Optional<Card> optional = customerCardRepository.findById(cardId);
		Card card = optional.orElseThrow(()-> new EKartException("Service.CARD_NOT_FOUND"));
		//Deleting specific card from DB.
		customerCardRepository.deleteById(card.getCardId());
	}
}
