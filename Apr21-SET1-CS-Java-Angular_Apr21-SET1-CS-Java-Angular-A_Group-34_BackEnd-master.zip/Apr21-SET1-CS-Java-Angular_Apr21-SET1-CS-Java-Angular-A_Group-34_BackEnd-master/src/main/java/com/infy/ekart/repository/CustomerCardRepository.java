package com.infy.ekart.repository;

import org.springframework.data.repository.CrudRepository;


import com.infy.ekart.entity.Card;



public interface CustomerCardRepository extends CrudRepository<Card, Integer>{
	
    //Function for fetching card using card number
	Card findByCardNumber(String cardNumber);

}
